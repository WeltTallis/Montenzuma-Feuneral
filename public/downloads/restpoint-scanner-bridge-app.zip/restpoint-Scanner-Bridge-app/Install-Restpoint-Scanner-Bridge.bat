@echo off
title Restpoint Scanner Bridge - Installer
echo.
echo ==========================================
echo   Restpoint Scanner Bridge - Installer
echo ==========================================
echo.
set "HERE=%~dp0"
set "AGENT=%HERE%agent.js"
if not exist "%AGENT%" (
  echo [ERROR] agent.js not found next to this installer.
  pause & exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js was not found on this computer.
  echo         Install Node 22+ from https://nodejs.org and re-run this installer.
  pause & exit /b 1
)
for /f "delims=" %%i in ('where node') do set "NODE_EXE=%%i"
echo [OK] Node found: %NODE_EXE%
echo.
echo Installing startup shortcut (runs the bridge at every login)...
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "LNK=%STARTUP%\Restpoint Scanner Bridge.lnk"
set "VBS=%TEMP%\rp_scanner_bridge_shortcut.vbs"
> "%VBS%" echo Set oWS = WScript.CreateObject("WScript.Shell")
>> "%VBS%" echo sLinkFile = "%LNK%"
>> "%VBS%" echo Set oLink = oWS.CreateShortcut(sLinkFile)
>> "%VBS%" echo oLink.TargetPath = "%NODE_EXE%"
>> "%VBS%" echo oLink.Arguments = """%AGENT%"""
>> "%VBS%" echo oLink.WorkingDirectory = "%HERE%"
>> "%VBS%" echo oLink.Description = "Restpoint Scanner Bridge"
>> "%VBS%" echo oLink.Save
cscript //nologo "%VBS%"
del "%VBS%" >nul 2>nul
if exist "%LNK%" (echo [OK] Autostart installed.) else (echo [WARN] Autostart shortcut could not be created.)
echo.
echo Scanner driver: install NAPS2 (free, MIT) once so Windows TWAIN/WIA
echo devices are visible:  https://github.com/nathaniel-mahieu/NAPS2
echo Verify with:  naps2 list
echo.
echo Starting the bridge now...
start "Restpoint Scanner Bridge" "%NODE_EXE%" "%AGENT%"
echo.
echo [DONE] The bridge is running on ws://localhost:8081.
echo        Open Restpoint, go to a deceased profile and press "Scan Docs".
echo.
timeout /t 6 >nul
