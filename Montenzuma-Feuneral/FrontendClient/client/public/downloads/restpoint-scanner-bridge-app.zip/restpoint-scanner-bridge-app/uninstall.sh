#!/usr/bin/env bash
systemctl --user disable --now restpoint-scanner-bridge.service 2>/dev/null || true
rm -rf "$HOME/.restpoint-scanner-bridge"
echo "[OK] Bridge removed."
