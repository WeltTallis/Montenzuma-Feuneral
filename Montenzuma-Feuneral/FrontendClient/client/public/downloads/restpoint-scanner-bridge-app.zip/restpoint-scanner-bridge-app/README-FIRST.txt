Restpoint Scanner Bridge - README FIRST
=======================================

WHAT THIS IS
  A small background app for the reception computer. It listens on
  ws://localhost:8081 and lets the Restpoint web app drive the physical
  scanner: click "Scan Docs" on a deceased profile -> the scanner runs ->
  a PDF is produced -> it is uploaded straight into that profile Documents.

QUICK INSTALL (Windows)
  1. Install Node.js 22 or newer if you do not have it (https://nodejs.org).
  2. Double-click  Install-Restpoint-Scanner-Bridge.bat
     - installs a startup shortcut (runs at every login)
     - starts the bridge immediately
  3. Install the free NAPS2 scanner driver once:
     https://github.com/nathaniel-mahieu/NAPS2
     Verify the scanner is visible:
       "C:\Program Files\NAPS2\NAPS2.Console.exe" --driver wia --listdevices

USE IT
  In Restpoint: open a deceased profile -> press "Scan Docs".
  Put the paper in the scanner tray and press "Scan Document".

TROUBLESHOOTING
  - "Scanner Bridge not found": start the bridge (Start-Restpoint-Scanner-Bridge.bat)
  - Scanner not detected: run --driver wia --listdevices (see above), then
    set the scanner name, e.g.
      set SCANNER_NAME=HP ScanJet Pro 2600 f1
      node agent.js

UNINSTALL
  Double-click  Uninstall-Restpoint-Scanner-Bridge.bat
