@echo off
title Restpoint Scanner Bridge - Uninstall
set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Restpoint Scanner Bridge.lnk"
if exist "%LNK%" (del "%LNK%" & echo [OK] Autostart removed.) else (echo Autostart shortcut not found.)
taskkill /FI "WINDOWTITLE eq Restpoint Scanner Bridge*" >nul 2>nul
echo Bridge processes with that window title were stopped (if any).
pause
