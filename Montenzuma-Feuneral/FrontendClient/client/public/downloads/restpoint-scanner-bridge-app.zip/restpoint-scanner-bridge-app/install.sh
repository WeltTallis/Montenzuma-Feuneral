#!/usr/bin/env bash
set -e
echo "== Restpoint Scanner Bridge installer =="
command -v node >/dev/null 2>&1 || { echo "[ERROR] Node.js 22+ is required."; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.restpoint-scanner-bridge"
cp -f "$HERE/agent.js" "$HOME/.restpoint-scanner-bridge/agent.js"
SERVICE_DIR="$HOME/.config/systemd/user"
if [ -d "$HOME/.config" ]; then
  mkdir -p "$SERVICE_DIR"
  cat > "$SERVICE_DIR/restpoint-scanner-bridge.service" <<EOF
[Unit]
Description=Restpoint Scanner Bridge
[Service]
ExecStart=%h/.restpoint-scanner-bridge/node-run.sh
Restart=always
[Install]
WantedBy=default.target
EOF
  cat > "$HOME/.restpoint-scanner-bridge/node-run.sh" <<EOF
#!/usr/bin/env bash
exec "$(command -v node)" "$HOME/.restpoint-scanner-bridge/agent.js"
EOF
  chmod +x "$HOME/.restpoint-scanner-bridge/node-run.sh"
  systemctl --user daemon-reload || true
  systemctl --user enable --now restpoint-scanner-bridge.service || true
  echo "[OK] systemd user service installed and started."
else
  echo "[i] No systemd user session detected - start it with: ./start.sh"
fi
echo "[DONE] Bridge installed. Open Restpoint and press Scan Docs on a profile."
