@echo off
title Restpoint Scanner Bridge
set "HERE=%~dp0"
where node >nul 2>nul || (echo [ERROR] Node.js not found. Run the installer first. & pause & exit /b 1)
for /f "delims=" %%i in ('where node') do set "NODE_EXE=%%i"
echo Starting Restpoint Scanner Bridge on ws://localhost:8081 ...
"%NODE_EXE%" "%HERE%agent.js"
pause
