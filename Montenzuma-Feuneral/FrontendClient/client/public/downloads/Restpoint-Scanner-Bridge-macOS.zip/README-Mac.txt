Restpoint Scanner Bridge for macOS

1. Install NAPS2 or another supported scanner command if you use physical hardware.
2. Double-click Install-Restpoint-Scanner-Bridge.command.
3. If macOS asks, right-click the file and choose Open.

The bridge installs as a hidden LaunchAgent and listens on ws://localhost:8081.
This package contains an Intel macOS executable. Apple Silicon Macs can run it
through Rosetta 2. A native arm64 build requires building on an Apple Silicon host.
