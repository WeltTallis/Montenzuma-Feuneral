#!/bin/bash
set -e

INSTALL_DIR="$HOME/Library/Application Support/Restpoint Scanner Bridge"
AGENT_PATH="$INSTALL_DIR/Restpoint Scanner Bridge"
PLIST_DIR="$HOME/Library/LaunchAgents"
PLIST_PATH="$PLIST_DIR/com.welttallis.restpoint-scanner-bridge.plist"

mkdir -p "$INSTALL_DIR" "$PLIST_DIR"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$SOURCE_DIR/Restpoint Scanner Bridge" "$AGENT_PATH"
chmod 755 "$AGENT_PATH"

cat > "$PLIST_PATH" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.welttallis.restpoint-scanner-bridge</string>
  <key>ProgramArguments</key><array><string>$AGENT_PATH</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$INSTALL_DIR/bridge.log</string>
  <key>StandardErrorPath</key><string>$INSTALL_DIR/bridge-error.log</string>
</dict></plist>
PLIST

launchctl bootout "gui/$(id -u)" "$PLIST_PATH" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST_PATH"
launchctl kickstart -k "gui/$(id -u)/com.welttallis.restpoint-scanner-bridge"
echo "Restpoint Scanner Bridge installed and running on ws://localhost:8081."
echo "The bridge starts automatically when you sign in."
